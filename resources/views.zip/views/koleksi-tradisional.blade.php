{{-- Simpan sebagai: views/koleksi-tradisional.blade.php --}}
@extends('layouts.guest')

@section('title', 'Koleksi Tradisional')

@section('content')

    <header class="relative">
        <img src="{{ asset('images/lptradisional.webp') }}" 
             onerror="this.onerror=null;this.src='https://placehold.co/1200x500/333333/999999?text=Museum+Hero'"
             alt="Pameran koleksi tradisional" 
             class="w-full h-64 object-cover">
        
        <div class="absolute inset-0 bg-black/60"></div>

        <div class="absolute inset-0 py-8 md:py-12 flex flex-col justify-between text-white">
            
            <div class="max-w-5xl mx-auto w-full px-8 flex flex-col justify-between h-full">

                {{-- PERBAIKAN TOMBOL KEMBALI --}}
                <a href="{{ Auth::check() ? route('beranda') : route('landing') }}" class="flex items-center space-x-2 text-white/90 hover:text-white transition-colors w-fit">
                    <i data-lucide="arrow-left" class="w-6 h-6"></i>
                    <span id="page-back">Kembali</span>
                </a>

                <div>
                    <h1 class="text-4xl md:text-5xl font-bold mb-2" id="koleksi-tradisional-title">Koleksi Tradisional</h1>
                    <p class="text-lg text-gray-200" id="koleksi-tradisional-subtitle">Jelajahi warisan budaya Indonesia melalui koleksi tradisional kami</p>
                </div>

            </div>
        </div>
    </header>

    <section class="py-12 md:py-20 bg-white">
        <div class="max-w-5xl mx-auto px-8"> 
            <h2 class="text-3xl font-bold text-museum-dark mb-4" id="koleksi-tradisional-about-title">Tentang Koleksi</h2>
            <p class="text-base text-gray-600 leading-relaxed" id="koleksi-tradisional-about-text">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>
    </section>

    <section class="py-12 md:py-16 bg-white">
        <div class="max-w-5xl mx-auto px-8"> 
            <h2 class="text-3xl font-bold text-museum-dark mb-6" id="koleksi-tradisional-gallery-title">Galeri (3x3)</h2>
            
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                <img src="https://placehold.co/600x400/cccccc/333333?text=Galeri+1" alt="Foto galeri 1" class="w-full h-48 object-cover rounded-lg shadow-md transition-transform hover:scale-105">
                <img src="https://placehold.co/600x400/cccccc/333333?text=Galeri+2" alt="Foto galeri 2" class="w-full h-48 object-cover rounded-lg shadow-md transition-transform hover:scale-105">
                <img src="https://placehold.co/600x400/cccccc/333333?text=Galeri+3" alt="Foto galeri 3" class="w-full h-48 object-cover rounded-lg shadow-md transition-transform hover:scale-105">
                <img src="https://placehold.co/600x400/cccccc/333333?text=Galeri+4" alt="Foto galeri 4" class="w-full h-48 object-cover rounded-lg shadow-md transition-transform hover:scale-105">
                <img src="https://placehold.co/600x400/cccccc/333333?text=Galeri+5" alt="Foto galeri 5" class="w-full h-48 object-cover rounded-lg shadow-md transition-transform hover:scale-105">
                <img src="https://placehold.co/600x400/cccccc/333333?text=Galeri+6" alt="Foto galeri 6" class="w-full h-48 object-cover rounded-lg shadow-md transition-transform hover:scale-105">
                <img src="https://placehold.co/600x400/cccccc/333333?text=Galeri+7" alt="Foto galeri 7" class="w-full h-48 object-cover rounded-lg shadow-md transition-transform hover:scale-105">
                <img src="https://placehold.co/600x400/cccccc/333333?text=Galeri+8" alt="Foto galeri 8" class="w-full h-48 object-cover rounded-lg shadow-md transition-transform hover:scale-105">
                <img src="https://placehold.co/600x400/cccccc/333333?text=Galeri+9" alt="Foto galeri 9" class="w-full h-48 object-cover rounded-lg shadow-md transition-transform hover:scale-105">
            </div>
        </div>
    </section>

    <section class="bg-museum-dark text-white p-12 text-center">
        <h2 class="text-3xl font-bold mb-3" id="koleksi-militer-cta-title">Kunjungi Koleksi Ini</h2>
        <p class="text-gray-300 max-w-lg mx-auto mb-6" id="koleksi-militer-cta-subtitle">
            Pesan tiket Anda sekarang dan lihat koleksi secara langsung.
        </p>
        {{-- TOMBOL UPDATE: MENGARAH KE PESAN TIKET --}}
        <a href="{{ route('pesan-tiket') }}" class="inline-block bg-brand-yellow text-gray-900 font-bold py-3 px-8 rounded-lg shadow-lg hover:bg-brand-yellow-hover transition-colors" id="koleksi-militer-cta-button">
            Pesan Tiket
        </a>
    </section>

@endsection