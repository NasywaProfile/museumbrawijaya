<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda Admin - Museum Brawijaya</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
    </style>
</head>

<body class="bg-[#FBFAF9] min-h-screen p-4 md:p-8">

    <div class="max-w-[1600px] mx-auto">

        <div class="flex justify-between items-center mb-8">
            <div>
                <h1 class="text-3xl font-bold text-[#69161D]">Beranda Admin</h1>
                <p class="text-gray-500 mt-1">Sistem Manajemen Tiket Museum</p>
            </div>
            <div class="flex items-center gap-4">
                <span class="text-sm font-medium text-gray-600">Halo, Admin</span>
                <form action="{{ route('logout') }}" method="POST">
                    @csrf
                    <button type="submit"
                        class="hidden sm:flex items-center space-x-1.5 px-3 py-2 border border-gray-300 rounded-lg text-black hover:bg-gray-50 hover:border-gray-400 transition-colors whitespace-nowrap text-sm">
                        <i data-lucide="log-out" class="w-4 h-4"></i><span id="nav-logout">Keluar</span>
                    </button>
                </form>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">

            <div class="bg-white border border-[#F0EAD6] p-6 rounded-xl flex flex-col justify-between h-32 shadow-sm">
                <div class="flex justify-between items-start">
                    <span class="text-gray-500 text-sm font-medium">Total Pengguna</span>
                    <div class="text-[#69161D] bg-[#FDF6E4] p-2 rounded-lg"><i data-lucide="users" class="w-5 h-5"></i>
                    </div>
                </div>
                <span class="text-3xl font-bold text-[#69161D]">{{ $totalUsers }}</span>
            </div>

            <div class="bg-white border border-[#F0EAD6] p-6 rounded-xl flex flex-col justify-between h-32 shadow-sm">
                <div class="flex justify-between items-start">
                    <span class="text-gray-500 text-sm font-medium">Tiket Terjual</span>
                    <div class="text-[#ECAE36] bg-[#FDF6E4] p-2 rounded-lg"><i data-lucide="ticket" class="w-5 h-5"></i>
                    </div>
                </div>
                <span class="text-3xl font-bold text-[#ECAE36]">{{ $totalTickets }}</span>
            </div>

            <div class="bg-white border border-[#F0EAD6] p-6 rounded-xl flex flex-col justify-between h-32 shadow-sm">
                <div class="flex justify-between items-start">
                    <span class="text-gray-500 text-sm font-medium">Akses Tur Virtual</span>
                    <div class="text-blue-600 bg-blue-50 p-2 rounded-lg"><i data-lucide="video" class="w-5 h-5"></i>
                    </div>
                </div>
                <span class="text-3xl font-bold text-blue-600">{{ $totalVirtualTour }}</span>
            </div>

            <div class="bg-white border border-[#F0EAD6] p-6 rounded-xl flex flex-col justify-between h-32 shadow-sm">
                <div class="flex justify-between items-start">
                    <span class="text-gray-500 text-sm font-medium">Total Pendapatan</span>
                    <div class="text-green-600 bg-green-50 p-2 rounded-lg"><i data-lucide="wallet" class="w-5 h-5"></i>
                    </div>
                </div>
                <span class="text-3xl font-bold text-green-600">Rp
                    {{ number_format($totalRevenue, 0, ',', '.') }}</span>
            </div>

        </div>

        @if(session('success'))
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-8 text-sm w-full">
                {{ session('success') }}
            </div>
        @endif

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">

            <div class="bg-white border border-[#F0EAD6] rounded-xl p-6 shadow-sm h-full min-h-[400px] flex flex-col">
                <div class="flex items-center gap-2 mb-6">
                    <i data-lucide="ticket" class="w-5 h-5 text-[#69161D]"></i>
                    <h2 class="text-xl font-bold text-[#1F1F1F]">Transaksi Tiket</h2>
                </div>

                <div class="overflow-x-auto flex-grow">
                    <table class="w-full text-sm text-left">
                        <thead class="text-xs text-gray-500 uppercase border-b border-gray-200">
                            <tr>
                                <th class="pb-3 font-medium w-1/3">Pengguna</th>
                                <th class="pb-3 font-medium w-1/4">Tanggal</th>
                                <th class="pb-3 font-medium w-1/4">Harga</th>
                                <th class="pb-3 font-medium text-center w-1/6">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            @forelse($ticketTransactions as $trx)
                                <tr class="hover:bg-gray-50">
                                    <td class="py-4 font-semibold text-gray-800">{{ $trx->user->name }}
                                        <div class="text-xs text-gray-400 font-normal">{{ $trx->quantity }} Tiket</div>
                                    </td>
                                    <td class="py-4 text-gray-500">
                                        {{ \Carbon\Carbon::parse($trx->visit_date)->format('d M Y') }}
                                    </td>
                                    <td class="py-4 font-medium text-[#69161D]">Rp
                                        {{ number_format($trx->total_price, 0, ',', '.') }}
                                    </td>
                                    <td class="py-4 text-center">

                                        @if($trx->status == 'pending')
                                            {{-- Konfirmasi --}}
                                            <form action="{{ route('admin.approve', $trx->id) }}" method="POST">
                                                @csrf
                                                <button type="submit"
                                                    class="bg-[#F0C442] hover:bg-[#d9ac30] text-[#69161D] px-3 py-1.5 rounded-lg text-xs font-bold shadow-sm whitespace-nowrap transition-colors">
                                                    Konfirmasi
                                                </button>
                                            </form>

                                        @elseif($trx->status == 'active')
                                            {{-- Scan / Pakai Tiket --}}
                                            <form action="{{ route('admin.redeem', $trx->id) }}" method="POST">
                                                @csrf
                                                <button type="submit"
                                                    class="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow-sm whitespace-nowrap transition-colors flex items-center gap-1 mx-auto">
                                                    <i data-lucide="scan-line" class="w-3 h-3"></i> Scan
                                                </button>
                                            </form>

                                        @elseif($trx->status == 'used')
                                            {{-- Sudah Dipakai --}}
                                            <span
                                                class="bg-gray-200 text-gray-500 px-3 py-1.5 rounded-full text-xs font-bold inline-flex items-center gap-1 whitespace-nowrap">
                                                <i data-lucide="check-circle-2" class="w-3 h-3"></i> Selesai
                                            </span>
                                        @endif

                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="4" class="py-8 text-center text-gray-500">Belum ada transaksi tiket.</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="bg-white border border-[#F0EAD6] rounded-xl p-6 shadow-sm h-full min-h-[400px] flex flex-col">
                <div class="flex items-center gap-2 mb-6">
                    <i data-lucide="video" class="w-5 h-5 text-[#69161D]"></i>
                    <h2 class="text-xl font-bold text-[#1F1F1F]">Transaksi Tur Virtual</h2>
                </div>

                <div class="overflow-x-auto flex-grow">
                    <table class="w-full text-sm text-left">
                        <thead class="text-xs text-gray-500 uppercase border-b border-gray-200">
                            <tr>
                                <th class="pb-3 font-medium w-1/3">Pengguna</th>
                                <th class="pb-3 font-medium w-1/4">Tanggal</th>
                                <th class="pb-3 font-medium w-1/4">Harga</th>
                                <th class="pb-3 font-medium text-center w-1/6">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            @forelse($virtualTourTransactions as $trx)
                                <tr class="hover:bg-gray-50">
                                    <td class="py-4 font-semibold text-gray-800">{{ $trx->user->name }}</td>
                                    <td class="py-4 text-gray-500">
                                        {{ \Carbon\Carbon::parse($trx->created_at)->format('d M Y') }}
                                    </td>
                                    <td class="py-4 font-medium text-[#69161D]">Rp
                                        {{ number_format($trx->total_price, 0, ',', '.') }}
                                    </td>
                                    <td class="py-4 text-center">
                                        @if($trx->status == 'pending')
                                            <form action="{{ route('admin.approve', $trx->id) }}" method="POST">
                                                @csrf
                                                <button type="submit"
                                                    class="bg-[#F0C442] hover:bg-[#d9ac30] text-[#69161D] px-3 py-1.5 rounded-lg text-xs font-bold shadow-sm whitespace-nowrap transition-colors">Konfirmasi</button>
                                            </form>
                                        @elseif($trx->status == 'active')
                                            <span
                                                class="bg-green-100 text-green-800 px-3 py-1.5 rounded-full text-xs font-bold inline-flex items-center gap-1">Aktif</span>
                                        @endif
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="4" class="py-8 text-center text-gray-500">Belum ada transaksi Tur Virtual.
                                    </td>
                                </tr>

                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>

    <script>
        lucide.createIcons();
    </script>
</body>

</html>