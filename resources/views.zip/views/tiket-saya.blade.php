<?php
use Illuminate\Support\Facades\Auth;
use App\Models\Transaction;
use Carbon\Carbon;

$user = Auth::user();

// LOGIKA FILTER:
if (isset($tickets)) {
    $tickets = $tickets->where('status', '!=', 'unpaid');
} else {
    $tickets = Transaction::where('user_id', $user->id)
        ->where('status', '!=', 'unpaid')
        ->where('category', '!=', 'Virtual Tour')
        ->latest()
        ->get();
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tiket Saya - Museum Brawijaya</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['"Segoe UI"', 'Roboto', 'Helvetica Neue', 'Arial', 'sans-serif'] },
                    colors: {
                        'primary-brown': '#7F1D1D', 'brand-red': '#69161D', 'bg-light': '#FBFAF9',
                        'cta-brown': '#92400E', 'tag-bg': '#fef3c7', 'tag-text': '#69161D',
                        'card-bg': '#FBFAF9', 'button-yellow': '#F0C442', 'museum-light': '#93501F', 'museum-dark': '#69161D',
                    }
                }
            }
        }
    </script>
    <style>
        .no-scrollbar::-webkit-scrollbar {
            display: none;
        }

        .no-scrollbar {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translate3d(0, 20px, 0);
            }

            to {
                opacity: 1;
                transform: translate3d(0, 0, 0);
            }
        }

        .animate-fade-in-up {
            animation: fadeInUp 0.4s ease-out forwards;
        }
    </style>
</head>
{{-- BODY: Layout Terkunci --}}

<body class="bg-bg-light font-sans text-gray-900 flex flex-col h-screen overflow-hidden">

    {{-- Navbar Start --}}
    <nav class="bg-bg-light p-4 shadow-xl sticky top-0 z-50 shrink-0">
        <div class="container mx-auto flex justify-between items-center max-w-7xl px-4 sm:px-6 lg:px-12">
            <div class="flex-shrink-0">
                <a href="{{ route('beranda') }}" class="text-xl font-bold text-brand-red tracking-wider">Museum
                    Brawijaya</a>
            </div>
            <div class="flex-1 flex justify-center px-4">
                <div class="flex items-center space-x-1 overflow-x-auto no-scrollbar">
                    <a href="{{ route('beranda') }}"
                        class="flex items-center space-x-1.5 px-3 py-2 text-gray-600 hover:text-brand-red hover:bg-gray-50 rounded-lg font-medium transition-colors whitespace-nowrap text-sm"><i
                            data-lucide="home" class="w-4 h-4"></i><span id="nav-home">Beranda</span></a>
                    <a href="{{ route('halaman-saya') }}"
                        class="flex items-center space-x-1.5 px-3 py-2 text-gray-600 hover:text-brand-red hover:bg-gray-50 rounded-lg font-medium transition-colors whitespace-nowrap text-sm"><i
                            data-lucide="layout-dashboard" class="w-4 h-4"></i><span id="nav-dashboard">Halaman
                            Saya</span></a>

                    {{-- AKTIF --}}
                    <a href="{{ route('tiket-saya') }}"
                        class="flex items-center space-x-1.5 px-3 py-2 bg-[#FDF6E4] rounded-lg text-brand-red font-semibold transition-colors whitespace-nowrap text-sm"><i
                            data-lucide="ticket" class="w-4 h-4"></i><span id="nav-ticket">Tiket Saya</span></a>

                    <a href="{{ route('virtual-tour') }}"
                        class="flex items-center space-x-1.5 px-3 py-2 text-gray-600 hover:text-brand-red hover:bg-gray-50 rounded-lg font-medium transition-colors whitespace-nowrap text-sm">
                        <i data-lucide="video" class="w-4 h-4"></i><span id="nav-vtour">Virtual Tour</span>
                    </a>
                    <a href="{{ route('riwayat') }}"
                        class="flex items-center space-x-1.5 px-3 py-2 text-gray-600 hover:text-brand-red hover:bg-gray-50 rounded-lg font-medium transition-colors whitespace-nowrap text-sm"><i
                            data-lucide="history" class="w-4 h-4"></i><span id="nav-history">Riwayat</span></a>

                </div>
            </div>
            <div class="flex items-center space-x-4 flex-shrink-0">
                <a href="{{ route('profil') }}"
                    class="flex items-center space-x-1.5 text-black font-medium hover:text-brand-red transition-colors whitespace-nowrap text-sm"><i
                        data-lucide="user" class="w-4 h-4"></i><span>{{ Auth::user()->name ?? 'Akun' }}</span></a>
                <form action="{{ route('logout') }}" method="POST"> @csrf <button type="submit"
                        class="hidden sm:flex items-center space-x-1.5 px-3 py-2 border border-gray-300 rounded-lg text-black hover:bg-gray-50 hover:border-gray-400 transition-colors whitespace-nowrap text-sm"><i
                            data-lucide="log-out" class="w-4 h-4"></i><span
                            id="nav-logout">Keluar</span></button><button type="submit"
                        class="sm:hidden flex items-center justify-center p-2 text-red-600 hover:bg-gray-50 rounded-lg transition-colors"><i
                            data-lucide="log-out" class="w-4 h-4"></i></button></form>
            </div>
        </div>
    </nav>
    {{-- Navbar End --}}

    {{-- Konten Utama --}}
    <main class="w-full max-w-7xl mx-auto px-6 md:px-10 py-10 flex-grow flex flex-col h-full overflow-hidden">

        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4 shrink-0">
            <div>
                <h1 class="text-3xl font-bold text-[#69161D]" id="ticket-page-title">Tiket Saya</h1>
                <p class="text-gray-500 mt-2" id="ticket-page-subtitle">Kelola dan unduh tiket kunjungan Anda</p>
            </div>

            @if(!$tickets->isEmpty())
                <a href="{{ route('pesan-tiket') }}"
                    class="inline-flex items-center justify-center px-6 py-2.5 bg-gradient-to-r from-museum-dark to-museum-light border border-white/40 text-white font-bold rounded-xl shadow-md hover:opacity-90 transition-all duration-300 transform hover:scale-[1.02] text-sm">
                    <i data-lucide="plus" class="w-4 h-4 mr-2"></i> Pesan Tiket Lainnya
                </a>
            @endif
        </div>

        @if(session('success'))
            <div
                class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6 w-full text-sm shrink-0">
                {{ session('success') }}
            </div>
        @endif

        {{-- AREA SCROLLABLE --}}
        <div class="flex-grow overflow-y-auto no-scrollbar pb-20">

            @if($tickets->isEmpty())
                {{-- TAMPILAN KOSONG (KOLOM LEBAR TAPI ISI KECIL) --}}
                <div class="h-full flex items-center justify-center">
                    {{--
                    PERBAIKAN DI SINI:
                    - max-w-4xl: Agar kotaknya lebar.
                    - Elemen dalam (icon, text, button): Ukuran standar/kecil.
                    --}}
                    <div
                        class="bg-[#FDFBF7] border border-[#F0EAD6] rounded-xl p-8 w-full max-w-4xl flex flex-col items-center justify-center text-center shadow-sm min-h-[300px]">

                        {{-- Ikon Kecil (w-10) --}}
                        <div class="mb-4 text-[#796B5F] bg-[#FDF6E4] p-4 rounded-full">
                            <i data-lucide="ticket" class="w-10 h-10"></i>
                        </div>

                        {{-- Judul Kecil (text-xl) --}}
                        <h2 class="text-xl font-bold text-[#1F1F1F] mb-2" id="ticket-empty-title">Belum Ada Tiket</h2>

                        {{-- Deskripsi Kecil (text-sm) --}}
                        <p class="text-gray-500 max-w-md mb-6 text-sm leading-relaxed" id="ticket-empty-desc">
                            Anda belum memiliki tiket kunjungan. Pesan tiket pertama Anda sekarang untuk mulai menjelajahi
                            museum!
                        </p>

                        {{-- Tombol Kecil (text-sm, padding standar) --}}
                        <a href="{{ route('pesan-tiket') }}"
                            class="inline-flex items-center justify-center px-6 py-2.5 bg-gradient-to-r from-museum-dark to-museum-light border border-white/40 text-white font-bold rounded-lg shadow-md hover:opacity-90 transition-all duration-300 transform hover:scale-[1.02] text-sm"
                            id="ticket-btn-new">
                            Pesan Tiket Baru
                        </a>
                    </div>
                </div>

            @else
                {{-- LIST TIKET (GRID 2 KOLOM) --}}
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    @foreach($tickets as $ticket)
                        <div
                            class="bg-white border border-gray-200 rounded-xl shadow-sm p-6 md:p-8 hover:shadow-md transition-shadow w-full flex flex-col gap-4 h-full">

                            <div
                                class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-dashed border-gray-100 pb-4">
                                <div>
                                    <div class="flex items-center gap-3 mb-1">
                                        <h2 class="text-xl font-bold text-brand-red">Tiket {{ $ticket->category }}</h2>
                                        @if($ticket->status == 'pending')
                                            <span
                                                class="bg-yellow-50 text-yellow-700 border border-yellow-200 text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">Menunggu
                                                Konfirmasi</span>
                                        @elseif($ticket->status == 'unpaid')
                                            <span
                                                class="bg-red-50 text-red-700 border border-red-200 text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">Belum
                                                Bayar</span>
                                        @elseif($ticket->status == 'active')
                                            <span
                                                class="bg-green-50 text-green-700 border border-green-200 text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">Aktif</span>
                                        @elseif($ticket->status == 'used')
                                            <span
                                                class="bg-gray-100 text-gray-600 border border-gray-300 text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">Selesai</span>
                                        @endif
                                    </div>
                                    <p class="text-xs text-gray-400 font-mono">ID: #{{ $ticket->id }}</p>
                                </div>

                                <div class="text-left md:text-right">
                                    <p class="text-[10px] uppercase text-gray-500 mb-0.5 font-semibold">Total Bayar</p>
                                    <span class="text-xl font-bold text-brand-red">Rp
                                        {{ number_format($ticket->total_price, 0, ',', '.') }}</span>
                                </div>
                            </div>

                            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                                <div>
                                    <span class="text-xs text-gray-400 block mb-1 uppercase tracking-wide">Tanggal</span>
                                    <div class="flex items-center gap-2 text-gray-800 font-medium text-base">
                                        <i data-lucide="calendar" class="w-4 h-4 text-brand-red"></i>
                                        {{ \Carbon\Carbon::parse($ticket->visit_date)->locale('id')->isoFormat('D MMM Y') }}
                                    </div>
                                </div>
                                <div>
                                    <span class="text-xs text-gray-400 block mb-1 uppercase tracking-wide">Jumlah</span>
                                    <div class="flex items-center gap-2 text-gray-800 font-medium text-base">
                                        <i data-lucide="users" class="w-4 h-4 text-brand-red"></i>
                                        {{ $ticket->quantity }} Orang
                                    </div>
                                </div>
                                <div class="col-span-2">
                                    <span class="text-xs text-gray-400 block mb-1 uppercase tracking-wide">Lokasi</span>
                                    <div class="flex items-center gap-2 text-gray-800 font-medium text-base">
                                        <i data-lucide="map-pin" class="w-4 h-4 text-brand-red"></i>
                                        Museum Brawijaya, Malang
                                    </div>
                                </div>
                            </div>

                            <div class="mt-auto pt-4 border-t border-gray-100">
                                @if($ticket->status == 'unpaid')
                                    <div class="flex justify-end">
                                        <a href="{{ route('pembayaran') }}"
                                            class="w-full bg-red-600 text-white px-4 py-2.5 rounded-lg font-bold hover:bg-red-700 transition-colors text-sm flex justify-center items-center gap-2 shadow-md">
                                            Lanjutkan Pembayaran <i data-lucide="arrow-right" class="w-4 h-4"></i>
                                        </a>
                                    </div>
                                @elseif($ticket->status == 'pending')
                                    <div
                                        class="bg-gray-50 rounded-lg p-3 text-center text-xs text-gray-500 border border-gray-100 flex items-center justify-center gap-2">
                                        <i data-lucide="clock" class="w-4 h-4 text-yellow-600"></i> Pembayaran sedang diverifikasi.
                                    </div>
                                @elseif($ticket->status == 'active')
                                    <div class="flex flex-col sm:flex-row justify-between items-center gap-3">
                                        <div class="flex items-center gap-2 text-xs text-gray-500">
                                            <i data-lucide="check-circle" class="w-4 h-4 text-green-500"></i>
                                            <span>Tiket siap digunakan.</span>
                                        </div>
                                        <button onclick="openQrModal('{{ $ticket->id }}')"
                                            class="w-full sm:w-auto bg-white border-2 border-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm font-bold flex items-center justify-center gap-2 hover:border-brand-red hover:text-brand-red transition-all shadow-sm">
                                            <i data-lucide="maximize" class="w-4 h-4"></i> Lihat QR
                                        </button>
                                    </div>
                                @elseif($ticket->status == 'used')
                                    <div
                                        class="bg-gray-50 rounded-lg p-3 text-center text-xs text-gray-500 border border-gray-200 flex items-center justify-center gap-2">
                                        <i data-lucide="check-circle-2" class="w-4 h-4 text-gray-400"></i> Terima kasih! Tiket telah
                                        digunakan.
                                    </div>
                                @endif
                            </div>
                        </div>
                    @endforeach
                </div>
            @endif
        </div>

    </main>

    {{-- MODAL QR CODE --}}
    <div id="qr-modal"
        class="fixed inset-0 z-[60] flex items-center justify-center px-4 bg-[#1F1F1F]/90 backdrop-blur-sm hidden transition-opacity duration-300 opacity-0">
        <div class="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-sm text-center relative transform transition-transform duration-300 scale-95"
            id="qr-modal-content">
            <div class="bg-white border border-[#E5E5E5] rounded-xl p-4 mb-6 inline-block shadow-sm">
                <img id="qr-image" src="" alt="QR Code Tiket" class="w-48 h-48 md:w-56 md:h-56 object-contain">
            </div>
            <p class="text-[#8C7A6B] text-sm md:text-base mb-8 font-medium">Scan QR code ini di pintu Museum Brawijaya
            </p>
            <button onclick="closeQrModal()"
                class="block w-full bg-[#69161D] hover:bg-[#5a1218] text-white font-semibold py-3.5 rounded-xl shadow-md transition-colors duration-300">Tutup
                Kode Tiket</button>
        </div>
    </div>

    <script src="{{ asset('js/translation.js') }}"></script>
    <script>
        lucide.createIcons();
        const modal = document.getElementById('qr-modal');
        const modalContent = document.getElementById('qr-modal-content');
        const qrImage = document.getElementById('qr-image');
        function openQrModal(ticketId) {
            qrImage.src = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=Tiket-Museum-${ticketId}&color=000000&bgcolor=ffffff`;
            modal.classList.remove('hidden');
            setTimeout(() => { modal.classList.remove('opacity-0'); modalContent.classList.remove('scale-95'); modalContent.classList.add('scale-100'); }, 10);
        }
        function closeQrModal() {
            modal.classList.add('opacity-0'); modalContent.classList.remove('scale-100'); modalContent.classList.add('scale-95');
            setTimeout(() => { modal.classList.add('hidden'); }, 300);
        }
        modal.addEventListener('click', function (e) { if (e.target === modal) closeQrModal(); });
    </script>

</body>

</html>