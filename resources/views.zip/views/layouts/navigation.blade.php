<nav class="bg-bg-light p-4 shadow-xl sticky top-0 z-50">
    <div class="container mx-auto flex justify-between items-center max-w-7xl px-4 sm:px-6 lg:px-12">
        {{-- LOGO --}}
        <a href="{{ route('landing') }}" class="text-xl font-bold text-brand-red tracking-wider">
            Museum Brawijaya
        </a>

        <div class="flex items-center space-x-4">
            {{-- TOMBOL GANTI BAHASA --}}
            <div class="relative">
                <button id="language-toggle" class="text-black">
                    <i class="fa-solid fa-globe"></i>
                    <i id="language-arrow" class="fa-solid fa-chevron-down text-xs ml-1 transition-transform duration-300"></i>
                </button>
                <div id="language-menu" class="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-2xl py-2 hidden origin-top-right transform transition duration-300 ease-out border border-gray-100">
                    <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 font-medium" data-lang="id">
                        Bahasa Indonesia
                    </a>
                    <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 font-medium" data-lang="en">
                        English Language
                    </a>
                </div>
            </div>
            
            {{-- 
                PERBAIKAN UTAMA:
                Menggunakan tag <a> (link) agar bisa diklik.
                href="{{ route('login') }}" mengarah ke halaman masuk.
            --}}
            <a href="{{ route('login') }}" class="px-4 py-2 bg-button-yellow text-brand-red font-semibold rounded-lg shadow-md transition duration-300 hover:opacity-90 cursor-pointer" id="nav-login">
                Masuk / Daftar
            </a>
            
        </div>
    </div>
</nav>