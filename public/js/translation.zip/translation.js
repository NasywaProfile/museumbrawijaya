// Simpan sebagai: public/js/translation.js
// (Full code di bawah ini persis sama dengan respons sebelumnya, sudah benar)

// =======================================================
// 1. KAMUS GABUNGAN (UNTUK SEMUA HALAMAN)
// =======================================================
// Simpan sebagai: public/js/translation.js

// Simpan sebagai: public/js/translation.js

// Simpan sebagai: public/js/translation.js

const translations = {
    'id': {
        // --- LANDING PAGE & BERANDA BODY ---
        'hero-title': 'Jelajahi Sejarah Indonesia di',
        'hero-description-text': 'Temukan koleksi bersejarah dan artefak yang menggambarkan perjalanan panjang bangsa Indonesia. Nikmati pengalaman museum yang interaktif dan edukatif.',
        'hero-button-1': 'Pesan Tiket Sekarang',
        'hero-button-2': 'Mulai Virtual Tour',
        'about-title': 'Tentang Museum Brawijaya',
        'about-description': 'Museum Brawijaya adalah museum militer yang didedikasikan untuk melestarikan sejarah perjuangan kemerdekaan Indonesia. Terletak di jantung kota Malang, museum ini menampilkan koleksi komprehensif artefak, dokumen, dan memorabilia dari era kolonial hingga kemerdekaan.',
        'about-location-label': 'Lokasi:',
        'about-hours-label': 'Jam Buka:',
        'about-hours-text': 'Senin - Minggu, 08:00 - 15:00',
        'about-guide-label': 'Panduan tersedia dalam',
        'about-guide-text': 'Bahasa Indonesia & Inggris',
        'about-card1-title': 'Buka Setiap Hari',
        'about-card1-text': 'Tidak ada hari libur',
        'about-card2-title': 'Virtual Tour',
        'about-card2-text': 'Teknologi 360°',
        'collection-title': 'Koleksi Unggulan',
        'collection-description': 'Jelajahi koleksi bersejarah berbagai periode penting dalam sejarah Indonesia',        'collection-card1-tag': 'Tradisional',
        'collection-card1-title': 'Koleksi Tradisional',
        'collection-card1-desc': 'Artefak Tradisional Indonesia',
        'collection-card2-tag': 'Sejarah',
        'collection-card2-title': 'Koleksi Sejarah',
        'collection-card2-desc': 'Dokumentasi perjuangan Indonesia',
        'collection-card3-tag': 'Militer',
        'collection-card3-title': 'Koleksi Militer',
        'collection-card3-desc': 'Seragam dan peralatan militer bersejarah',
        
        // --- AUTH PAGES ---
        'page-back': 'Kembali',
        'auth-daftar-title': 'Daftar',
        'auth-daftar-subtitle': 'Buat akun baru untuk mengakses layanan museum',
        'auth-label-nama': 'Nama Lengkap',
        'auth-label-wa': 'WhatsApp (Opsional)',
        'auth-label-email': 'Email',
        'auth-label-password': 'Password',
        'auth-btn-daftar': 'Daftar',
        'auth-text-have-account': 'Sudah punya akun?',
        'auth-link-login': 'Masuk di sini',
        'auth-masuk-title': 'Masuk',
        'auth-masuk-subtitle': 'Masuk ke akun Museum Brawijaya Anda',
        'auth-btn-masuk': 'Masuk',
        'auth-text-no-account': 'Belum punya akun?',
        'auth-link-daftar': 'Daftar di sini',

        // --- NAVBAR ---
        'nav-home': 'Beranda',
        'nav-dashboard': 'Halaman Saya',
        'nav-ticket': 'Tiket Saya',
        'nav-vtour': 'Virtual Tour',
        'nav-history': 'Riwayat',
        'nav-account': 'Akun',
        'nav-logout': 'Keluar',
        'nav-login': 'Masuk / Daftar',

        // --- FOOTER ---
        'footer-cta-title': 'Siap Menjelajahi Sejarah?',
        'footer-cta-desc': 'Bergabunglah dengan ribuan pengunjung yang telah merasakan pengalaman tak terlupakan di Museum Brawijaya',
        'footer-cta-btn1': 'Daftar Sekarang',
        'footer-cta-btn2': 'Pesan Sekarang',
        'footer-info-desc': 'Melestarikan sejarah dan budaya Indonesia.',
        'footer-hours-title': 'Jam Operasional',
        'footer-hours-text': 'Senin - Minggu',
        'footer-contact-title': 'Kontak',
        'footer-copyright': '© 2025 Museum Brawijaya. Semua hak dilindungi.',

        // --- HALAMAN SAYA (DASHBOARD) --- 
        'dashboard-welcome': 'Selamat Datang',
        'dashboard-subtitle': 'Kelola kunjungan dan nikmati pengalaman Museum Brawijaya',
        'dashboard-card-ticket-title': 'Tiket Mendatang',
        'dashboard-card-ticket-empty': 'Belum ada tiket aktif',
        'dashboard-btn-book': 'Pesan Tiket',
        'dashboard-card-vtour-title': 'Virtual Tour',
        'dashboard-card-vtour-empty': 'Belum memiliki akses',
        'dashboard-btn-buy-vtour': 'Beli Virtual Tour',
        'dashboard-trans-title': 'Transaksi Terbaru',
        'dashboard-trans-subtitle': '5 transaksi terakhir Anda',
        'dashboard-trans-empty': 'Belum ada transaksi',

        // --- HALAMAN KOLEKSI ---
        'koleksi-militer-title': 'Koleksi Militer',
        'koleksi-militer-subtitle': 'Jelajahi warisan budaya Indonesia melalui koleksi militer kami',
        'koleksi-militer-about-title': 'Tentang Koleksi',
        'koleksi-militer-about-text': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit...',
        'koleksi-militer-gallery-title': 'Galeri (3x3)',
        'koleksi-militer-cta-title': 'Kunjungi Koleksi Ini',
        'koleksi-militer-cta-subtitle': 'Pesan tiket Anda sekarang dan lihat koleksi secara langsung.',
        'koleksi-militer-cta-button': 'Pesan Tiket',
        'koleksi-sejarah-title': 'Koleksi Sejarah',
        'koleksi-sejarah-subtitle': 'Jelajahi warisan budaya Indonesia melalui koleksi sejarah kami',
        'koleksi-sejarah-about-title': 'Tentang Koleksi',
        'koleksi-sejarah-about-text': 'Lorem ipsum dolor sit amet...',
        'koleksi-sejarah-gallery-title': 'Galeri (3x3)',
        'koleksi-sejarah-cta-title': 'Kunjungi Koleksi Ini',
        'koleksi-sejarah-cta-subtitle': 'Pesan tiket Anda sekarang dan lihat koleksi secara langsung.',
        'koleksi-sejarah-cta-button': 'Pesan Tiket',
        'koleksi-tradisional-title': 'Koleksi Tradisional',
        'koleksi-tradisional-subtitle': 'Jelajahi warisan budaya Indonesia melalui koleksi tradisional kami',
        'koleksi-tradisional-about-title': 'Tentang Koleksi',
        'koleksi-tradisional-about-text': 'Lorem ipsum dolor sit amet...',
        'koleksi-tradisional-gallery-title': 'Galeri (3x3)',
        'koleksi-tradisional-cta-title': 'Kunjungi Koleksi Ini',
        'koleksi-tradisional-cta-subtitle': 'Pesan tiket Anda sekarang dan lihat koleksi secara langsung.',
        'koleksi-tradisional-cta-button': 'Pesan Tiket',

        // --- HALAMAN TIKET SAYA ---
        'ticket-page-title': 'Tiket Saya',
        'ticket-page-subtitle': 'Kelola dan unduh tiket kunjungan Anda',
        'ticket-empty-title': 'Belum Ada Tiket',
        'ticket-empty-desc': 'Anda belum memiliki tiket kunjungan. Pesan tiket pertama Anda sekarang!',
        'ticket-btn-new': 'Pesan Tiket Baru',
    },
    'en': {
        // --- LANDING PAGE & BERANDA BODY ---
        'hero-title': 'Explore Indonesian History at',
        'hero-description-text': 'Discover historical collections and artifacts that depict the long journey of the Indonesian nation. Enjoy an interactive and educational museum experience.',
        'hero-button-1': 'Book Tickets Now',
        'hero-button-2': 'Start Virtual Tour',
        'about-title': 'About Museum Brawijaya',
        'about-description': 'Museum Brawijaya is a military museum dedicated to preserving the history of Indonesia\'s struggle for independence. Located in the heart of Malang, this museum displays a comprehensive collection of artifacts, documents, and memorabilia from the colonial era to independence.',
        'about-location-label': 'Location:',
        'about-hours-label': 'Opening Hours:',
        'about-hours-text': 'Monday - Sunday, 08:00 - 15:00',
        'about-guide-label': 'Guides available in',
        'about-guide-text': 'Indonesian & English',
        'about-card1-title': 'Open Every Day',
        'about-card1-text': 'No holidays',
        'about-card2-title': 'Virtual Tour',
        'about-card2-text': '360° Technology',
        'collection-title': 'Featured Collections',
        'collection-description': 'Explore our historical collections that cover various important periods in Indonesian history',
        'collection-card1-tag': 'Traditional',
        'collection-card1-title': 'Traditional Collection',
        'collection-card1-desc': 'Traditional Indonesian Artifacts',
        'collection-card2-tag': 'Historical',
        'collection-card2-title': 'Historical Collection',
        'collection-card2-desc': 'Documentation of Indonesian struggle',
        'collection-card3-tag': 'Military',
        'collection-card3-title': 'Military Collection',
        'collection-card3-desc': 'Historical military uniforms and equipment',
        
        // --- AUTH PAGES ---
        'page-back': 'Back',
        'auth-daftar-title': 'Register',
        'auth-daftar-subtitle': 'Create a new account to access museum services',
        'auth-label-nama': 'Full Name',
        'auth-label-wa': 'WhatsApp (Optional)',
        'auth-label-email': 'Email',
        'auth-label-password': 'Password',
        'auth-btn-daftar': 'Register',
        'auth-text-have-account': 'Already have an account?',
        'auth-link-login': 'Login here',
        'auth-masuk-title': 'Login',
        'auth-masuk-subtitle': 'Login to your Museum Brawijaya account',
        'auth-btn-masuk': 'Login',
        'auth-text-no-account': 'Don\'t have an account?',
        'auth-link-daftar': 'Register here',

        // --- NAVBAR ---
        'nav-home': 'Home',
        'nav-dashboard': 'My Page',
        'nav-ticket': 'My Ticket',
        'nav-vtour': 'Virtual Tour',
        'nav-history': 'History',
        'nav-account': 'Account',
        'nav-logout': 'Logout',
        'nav-login': 'Login / Register',

        // --- FOOTER ---
        'footer-cta-title': 'Ready to Explore History?',
        'footer-cta-desc': 'Join thousands of visitors who have had an unforgettable experience at Museum Brawijaya',
        'footer-cta-btn1': 'Register Now',
        'footer-cta-btn2': 'Book Now',
        'footer-info-desc': 'Preserving Indonesian history and culture.',
        'footer-hours-title': 'Operational Hours',
        'footer-hours-text': 'Monday - Sunday',
        'footer-contact-title': 'Contact',
        'footer-copyright': '© 2025 Museum Brawijaya. All rights reserved.',

        // --- HALAMAN SAYA (DASHBOARD) --- 
        'dashboard-welcome': 'Welcome',
        'dashboard-subtitle': 'Manage your visits and enjoy the Museum Brawijaya experience',
        'dashboard-card-ticket-title': 'Upcoming Tickets',
        'dashboard-card-ticket-empty': 'No active tickets',
        'dashboard-btn-book': 'Book Ticket',
        'dashboard-card-vtour-title': 'Virtual Tour',
        'dashboard-card-vtour-empty': 'No access yet',
        'dashboard-btn-buy-vtour': 'Buy Virtual Tour',
        'dashboard-trans-title': 'Recent Transactions',
        'dashboard-trans-subtitle': 'Your last 5 transactions',
        'dashboard-trans-empty': 'No transactions yet',

        // --- HALAMAN KOLEKSI ---
        'koleksi-militer-title': 'Military Collection',
        'koleksi-militer-subtitle': 'Explore Indonesian cultural heritage through our military collection',
        'koleksi-militer-about-title': 'About The Collection',
        'koleksi-militer-about-text': 'Lorem ipsum dolor sit amet...',
        'koleksi-militer-gallery-title': 'Gallery (3x3)',
        'koleksi-militer-cta-title': 'Visit This Collection',
        'koleksi-militer-cta-subtitle': 'Book your tickets now and see the collection in person.',
        'koleksi-militer-cta-button': 'Book Ticket',
        'koleksi-sejarah-title': 'Historical Collection',
        'koleksi-sejarah-subtitle': 'Explore Indonesian cultural heritage through our historical collection',
        'koleksi-sejarah-about-title': 'About The Collection',
        'koleksi-sejarah-about-text': 'Lorem ipsum dolor sit amet...',
        'koleksi-sejarah-gallery-title': 'Gallery (3x3)',
        'koleksi-sejarah-cta-title': 'Visit This Collection',
        'koleksi-sejarah-cta-subtitle': 'Book your tickets now and see the collection in person.',
        'koleksi-sejarah-cta-button': 'Book Ticket',
        'koleksi-tradisional-title': 'Traditional Collection',
        'koleksi-tradisional-subtitle': 'Explore Indonesian cultural heritage through our traditional collection',
        'koleksi-tradisional-about-title': 'About The Collection',
        'koleksi-tradisional-about-text': 'Lorem ipsum dolor sit amet...',
        'koleksi-tradisional-gallery-title': 'Gallery (3x3)',
        'koleksi-tradisional-cta-title': 'Visit This Collection',
        'koleksi-tradisional-cta-subtitle': 'Book your tickets now and see the collection in person.',
        'koleksi-tradisional-cta-button': 'Book Ticket',

        // --- HALAMAN TIKET SAYA ---
        'ticket-page-title': 'My Tickets',
        'ticket-page-subtitle': 'Manage and download your visit tickets',
        'ticket-empty-title': 'No Tickets Yet',
        'ticket-empty-desc': 'You do not have any visit tickets yet. Book your first ticket now!',
        'ticket-btn-new': 'Book New Ticket',
    }
};

function switchLanguage(lang) {
    if (!translations[lang]) return;
    localStorage.setItem('preferred_lang', lang);
    const langData = translations[lang];
    Object.keys(langData).forEach(key => {
        const element = document.getElementById(key);
        if (element) {
            element.innerHTML = langData[key];
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    const savedLang = localStorage.getItem('preferred_lang');
    if (savedLang) {
        switchLanguage(savedLang);
    }

    const toggleButton = document.getElementById('language-toggle');
    const languageMenu = document.getElementById('language-menu');
    const languageArrow = document.getElementById('language-arrow');

    function toggleLanguageMenu() {
        const isHidden = languageMenu.classList.contains('hidden');
        if (isHidden) {
            languageMenu.classList.remove('hidden');
            if(languageArrow) languageArrow.classList.add('rotate-180');
        } else {
            languageMenu.classList.add('hidden');
            if(languageArrow) languageArrow.classList.remove('rotate-180');
        }
    }

    if (toggleButton) {
        toggleButton.addEventListener('click', (event) => {
            event.stopPropagation();
            toggleLanguageMenu();
        });
    }

    document.addEventListener('click', (event) => {
        if (toggleButton && languageMenu && !toggleButton.contains(event.target) && !languageMenu.contains(event.target)) {
            if (!languageMenu.classList.contains('hidden')) {
                languageMenu.classList.add('hidden');
                if (languageArrow) languageArrow.classList.remove('rotate-180');
            }
        }
    });

    if (languageMenu) {
        languageMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const selectedLang = link.getAttribute('data-lang');
                switchLanguage(selectedLang);
                toggleLanguageMenu();
            });
        });
    }

    if (typeof lucide !== 'undefined' && lucide.createIcons) {
        lucide.createIcons();
    }
});